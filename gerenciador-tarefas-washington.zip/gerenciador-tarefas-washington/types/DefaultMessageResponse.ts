export type DefaultMessageResponse = {
    error? : string,
    msg?: string
}