export type User = {
    _id: string | undefined,
    name: string,
    email: string,
    password: string
}